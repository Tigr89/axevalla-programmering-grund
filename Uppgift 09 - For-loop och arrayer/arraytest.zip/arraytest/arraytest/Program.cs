﻿using System.Diagnostics.Metrics;

string[] names = new string[3];

Console.WriteLine("Please name three employees.");

names[0] = Console.ReadLine();
Console.Clear();
Console.WriteLine(names[0] + "? That's a DUMB name.\nGive me, like, a name that doesn't suck for this next one.\n\nWrite a GOOD name:");

names[1] = Console.ReadLine();
Console.Clear();
Console.WriteLine("...Okay. That's an improvement, I guess. If you really stretch the definition of improvement.\nWhat I'm saying is, " + names[1] + "? Also a pretty terrible name.\n\nAlright, last chance. Give it your all, I think I still have a smidge of faith in you.\n\n(Try to) Write a GOOD name again:");

names[2] = Console.ReadLine();
Console.Clear();
Console.WriteLine(names[2] + ".\n" + names[2] + "?\n\n" + names[2] + "...\n\n[ENTER] to continue");
Console.ReadLine();

Console.Clear();
Console.WriteLine("WHAT kind of paint thinner are you sniffing?!\n'" + names[2] + "'... I can't believe this.\nI was like, MAYBE okay with " + names[0] + " and " + names[1] + ".\n\nBut " + names[2] + "? I'm 100% sure that name constitutes AT LEAST a war crime." + "\n\n[ENTER] to continue");
Console.ReadLine();

Console.Clear();
Console.WriteLine("Okay, okay, OK. Need to keep my composure...\nAlright, okay.\n" + names[0] + ", " + names[1] + " and " + names[2] + ".\nTruly a group of individuals with CHARMING and NOT TERRIBLE names!" + "\n\n[ENTER] to continue");
Console.ReadLine();

Console.Clear();
Console.WriteLine("Just type in a 1, 2 or 3 to pull up a neat info paragraph about your little test subjects!\nOr write a 0 to stop looking and just list everyone's GREEAAT names.");
string subject_id = "";
bool has_written_0 = new bool();
while (has_written_0 == false)
{
    Console.WriteLine("Type a number between 0-3:");
    subject_id = Console.ReadLine();
    Console.Clear();
    switch (subject_id)
    {
        case "0":
            has_written_0 = true;
            break;

        case "1":
            Console.WriteLine("Subject Name: " + names[0] + "\nAge: Around 19 to 43. Somewhere between those two, that's for sure.\nInterests: I don't know, and I also don't really care.\nAdditional info: Convicted for aggravated assault and purchasing FIFA 14.\nMostly the latter, though.\nGREAT name.\n\n");
            break;

        case "2":
            Console.WriteLine("Subject Name: " + names[1] + "\nAge: 14\nInterests: Fortnite.\nAdditional info: Is a child, and should not be working here.\nLike, we are breaking child labor laws right now...\nAlso has a REALLY GOOD name.\n\n");
            break;

        case "3":
            Console.WriteLine("Subject Name: " + names[2] + "\nAge 47509\nInterests: Watching over the many lives they've created, cooking soup.\nAdditional info: This one is a primordial being, not of this realm.\nWe are truly blessed to have such a great worker here.\nName is really bad, though. I mean no it's really good.\n\n");
            break;

        default:
            Console.WriteLine("bro how hard is it to just write a number between 0-3?\n");
            break;
    }
}

for (int i = 0; i < names.Length; i++)
{
    Console.WriteLine("Employee #" + (i + 1) + ": " + names[i]);
}

Console.WriteLine("\n\nOkay, that's all. Bye now.\nI tried to implement a thing where leaving an empty string would be invalid, but then I looked at the time and saw that I probably can't do that within 3 minutes.");